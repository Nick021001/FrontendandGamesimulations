import itertools
import numpy as np
import random
import matplotlib.pyplot as plt
from play import play
#firom deal import deal
from creating_cards import card_creation
from combination_function import *
from remove_after_set_function import *
from compair_card_combinations import *

liste_play_cards = []
liste_play_cards = []
liste_sets_overall = []
founded_sets_in_100_games = []   #every list we need to fill later
choice = []
SAMPLE_SIZE = 100

# cardgame = card_creation(('Lila', 'Rot', 'Grün'), set(np.arange(1, 4)), ('Raupe', 'Stern', 'Oval'),
#                              ('Voll', 'leer', 'gestrichelt'))

for cycle in range(SAMPLE_SIZE): #this loop defines the amount of how games we will play
    cardgame = card_creation(('Lila', 'Rot', 'Grün'), set(np.arange(1, 4)), ('Raupe', 'Stern', 'Oval'),
                             ('Voll', 'leer', 'gestrichelt'))
    while len(cardgame):
        dict_check_set = {}
        def check_set(liste_play_cards):
            current_list_sets = []
            play(cardgame, liste_play_cards, choice) # -> calling play function
            print(len(liste_play_cards)) # -> just observing reasons
            print(len(cardgame)) # -> just observing reasons
            combinations_of_every_posisble_set = combinations_of_cards(liste_play_cards) # -> calling the combination of cards function
            for idx, ele in enumerate(combinations_of_every_posisble_set):
                dict_check_set[idx] = ele

            for i in dict_check_set.keys():
                compair_prop(combinations_of_every_posisble_set[i][0], combinations_of_every_posisble_set[i][1],
                             combinations_of_every_posisble_set[i][2], current_list_sets) # -> calling the compair_prop_function

            # liste_sets_overall.append(current_list_sets)
            for i in range(len(current_list_sets)):
                liste_sets_overall.append(current_list_sets[i])
            remove_after_set(current_list_sets, liste_play_cards)
            current_list_sets.clear()
            if len(cardgame) == 0:
                founded_sets_in_100_games.append(len(liste_sets_overall))
                liste_sets_overall.clear()
                print('Das ist der '+str(cycle+1)+'te Spieldurchlauf')
            return liste_play_cards


        check_set(liste_play_cards)

print(founded_sets_in_100_games)

print('wir haben pro durchlauf '+str(np.array(founded_sets_in_100_games).mean())+' gefunden')

