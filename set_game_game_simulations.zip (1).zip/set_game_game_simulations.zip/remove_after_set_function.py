new_list = []
import numpy as np
def unique(list1):
        # initialize a null list
        unique_list = []
        # traverse for all elements
        for x in list1:
            # check if exists in unique_list or not
            if x not in unique_list:
                unique_list.append(x)

        # print list
        return unique_list


def remove_after_set(tempoäre_liste_sets, liste_play_cards, max_liste_sets=2): # the variables are the Playcards, the current founded sets and the maximum list of sets which the game will remove
    if len(tempoäre_liste_sets) > 0 and len(tempoäre_liste_sets) <= max_liste_sets:  # if there is any sets founded we will looking for the number of the founded sets we will just look the first two sets founded
        for i in range(len(tempoäre_liste_sets)):
            for k in tempoäre_liste_sets[i]:
                new_list.append(k)

    if len(tempoäre_liste_sets) > 0 and len(tempoäre_liste_sets) > max_liste_sets:
        for i in range(len(tempoäre_liste_sets[:max_liste_sets])):
            for k in tempoäre_liste_sets[i]:
                new_list.append(k)

    else:
        pass

    if len(tempoäre_liste_sets) > 0 and len(unique(new_list)) % 3 == 0: # if there is 3 or 6 unique cards in the unique list than we will remove very card from the list
        for i in unique(new_list):
            liste_play_cards.remove(i)

    if len(tempoäre_liste_sets) > 0 and len(unique(new_list)) % 3 == 1:
        for i in unique(new_list)[:-1]:
            liste_play_cards.remove(i)                                 # if there is 4 or 5 unique cards than we will remove the first 3 cards from the list play cards

    if len(tempoäre_liste_sets) > 0 and len(unique(new_list)) % 3 == 2:
        for i in unique(new_list)[:-2]:
            liste_play_cards.remove(i)

    new_list.clear()

    return liste_play_cards
