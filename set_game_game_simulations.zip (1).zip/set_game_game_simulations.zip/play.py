import random
#play_card = Cards on the table
#card_deck = all cards in deck
# if statements for removing by certain conditions
def play(card_deck, play_card, choice, number_play_cards=12, default_wert=3):
    if not len(card_deck):
        return False
    if len(play_card) < number_play_cards and number_play_cards - len(play_card) <= len(card_deck) > 0:
        choice = random.sample(list(card_deck.keys()), k=number_play_cards - len(play_card))

    if len(play_card) < number_play_cards and number_play_cards - len(play_card) > len(card_deck) > 0:
        choice = random.sample(list(card_deck.keys()), k=len(card_deck))

    if len(play_card) >= number_play_cards and len(card_deck.keys()) >= default_wert:
        choice = random.sample(list(card_deck.keys()), k=default_wert)

    for i in choice:
        play_card.append(card_deck[i])
        card_deck.pop(i)

    return card_deck


