def combinations_of_cards(liste_play_cards):
    card_combinations = {}
    for idx, ele in enumerate(liste_play_cards):
        card_combinations[idx] = ele

    list_variation_playing_cards = [[card_combinations[i],card_combinations[j],card_combinations[k]] for i in list(card_combinations.keys())
                                    for j in list(card_combinations.keys()) for k in list(card_combinations.keys()) if i != j and i != k and j != k if i < j and i < k and j < k]

    return list_variation_playing_cards