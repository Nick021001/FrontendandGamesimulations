#liste_sets = []
from remove_after_set_function import *
def compair_prop(var1, var2, var3, current_list_sets):
    setA , setB, setC  = set(var1), set(var2), set(var3)
    difference1, difference2, difference3 = setA.symmetric_difference(setB), setB.symmetric_difference(setC), setA.symmetric_difference(setC) # here all elements are stored which form a difference set mathematically A ∆ B, B ∆ C, A ∆ C
    set_differences = difference1.union(difference2, difference3) # here the symmetric differences are united to a set
    gemeinsamkeitenA, gemeinsamkeitenB, gemeinsamkeitenC =  setA.intersection(setB), setB.intersection(setC), setA.intersection(setC)  # here the intersections are formed Mathematically A u B, B u C, A u C
    set_gemeinsamkeiten = gemeinsamkeitenA.union(gemeinsamkeitenB, gemeinsamkeitenC) # here the intersections are united
    if 3*len(set_gemeinsamkeiten) + len(set_differences) == 12:
        print('yes we have a set '+str(var1)+str(var2)+str(var3)+' This is a set because we have this similarities '+str(set_gemeinsamkeiten)+' and the everything else is different '+str(set_differences))
        current_list_sets.append([var1, var2, var3])
        #liste_sets.append([var1, var2, var3])
    else:
        reason_no_set = set_gemeinsamkeiten.intersection(set_differences)
        print('Sorry this combinations is no set we found this element '+str(reason_no_set)+' just in two cards which is a no go for set'+str(var1)+str(var2)+str(var3))


    return current_list_sets

# why this formula was chosen is the following reason: we compare three cards with 4 properties each, if the properties of the cards are
        # are different then we have 12 different elements when we mix the 3 sets, we call this antiset. But if there are matching elements, all non-matching elements must be different.
        # we calculate the similarities times 3 because in a mathematical set the number of elements doesn't matter, but for us it does and if the elements in the sets match we have them in principle 3 times present.
        # But why must the + the length of the differences result in 12? By forming the symmetrical difference for all sets, we prevent that there are elements that only appear in 2 of the 3 sets, which is a K.O criterion for a set.
        # so now you can imagine that if there are 2 matches for each set, then 2 elements must be completely different from each other, so their difference must be 6 3*2 matches + 6 different gives 12 so it works the same way for one or 3 commonalities

