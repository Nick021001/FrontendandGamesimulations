def card_creation(farbe, anzahl, form, füllung):
    liste_zusammensetzung = []
    for i in farbe:
        for k in anzahl:
            for x in form:
                for y in füllung:
                    liste_zusammensetzung.append([i, k, x, y])

    liste_karten = []
    for i in range(len(liste_zusammensetzung) + 1):
        liste_karten.append('Karte ' + str(i))

    dict_card_overview = dict(zip(liste_karten, liste_zusammensetzung))

    return dict_card_overview # Cards are offset with keys and stored in a dict which are simply card plus a number from 1 to 81