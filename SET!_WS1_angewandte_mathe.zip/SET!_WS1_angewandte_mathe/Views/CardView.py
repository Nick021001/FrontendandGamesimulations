import pygame
from consts import *
from util import inverted






class CardView:
    def __init__(self, gv, card, x, y, image, scale):
        self.card = card
        self.gv = gv
        width = image.get_width()
        height = image.get_height()
        self.image = pygame.transform.scale(image, (int(width * scale), int(height * scale)))
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)
        self.clicked = False
        self.selected = False
        self.font = pygame.font.Font("assets/DejaVuSans.ttf", 50)

    def draw(self, surface):
        action = False

        pos = pygame.mouse.get_pos()

        # check mouseover and clicked conditions
        if self.rect.collidepoint(pos):
            self.clicked = not self.clicked
            if pygame.mouse.get_pressed()[0]:
                # if there are 3 selected cards, only allow deselecting
                if self.gv.less_than_max_cards_selected() or self.selected:
                    self.image = inverted(self.image, INV_COLOR)
                    self.selected = not self.selected
                    action = True

        # draw button on screen
        surface.blit(self.image, (self.rect.x, self.rect.y))
        text = self.font.render(self.card.pretty_print(), False, self.card.get_color())
        surface.blit(text, (self.rect.x + self.get_padding(), self.rect.y + 18))

        return action

    def get_padding(self):
        return 25 * (3 - int(self.card.quantity)) + 40
