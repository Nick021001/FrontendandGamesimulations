# "SET!" Angewandte Mathematik WS1 EwR Projekt
> Niklas Rother(934510)

> Baris Numanoglu(939003)


## Thema: Das Kartenspiel SET! ist ein Assoziationsspiel. 
Das Spiel besteht aus 81 Karten.
Auf den Karten sind bestimmte Symbole abgedruckt.
Diese Symbole haben verschiedene Farben, Formen und Füllungen
und treten einfach, zweifach oder dreifach pro Karte auf.
Alle Symbole auf einer Karte 
haben jedoch die gleiche Farbe, Form und Füllung.

So lässt sich jede der 81 Karten eindeutig durch die Ausprägungen
der Eigenschaften Farbe, Form, Füllung und Anzahl charakterisieren.
Für jede dieser vier Eigenschaften existieren drei mögliche Ausprägungen.

Das Spielziel ist ein 'SET!' zu finden.
Es gibt verschiedene Definitionen von 'SET!' je nach Spielvariante.
Ein 'SET!' im aktuellen Code besteht aus drei Karten,
die entweder drei gleiche,
oder drei verschiedene und eine gleiche,
oder zwei verschiedene und zwei gleiche,
oder vier verschieden Eigentschaften besitzen.
Sie werden aus 9 aufgedeckten Karten gewählt.
Ein gültiges 'SET!' wird entfernt 
und durch drei Karten aus dem Hauptdeck ersetzt.
Wenn man kein 'SET!' finden kann, hat man die Möglichkeit,
drei zufällig gewählte Karten zu ersetzen.

**Projektziel:** Das Üben der Inhalte aus der Vorlesung,
der Kooperation und der Organisation, sowie der Eigenrecherche.
Des Weiteren wollten wir einen Eindruck
von der Gestaltung eines relativ komplexen Codes 
und dessen Optimierung gewinnen.

## Ausführung
* Projekt wurde mit `python 3.9` erstellt. Wenn nötig erstellen Sie einen virtual environment dafür.
* Installieren Sie nötige Zusatzbibliotheken durch `pip -r requirements.txt`
* Führen Sie python main.py aus

## Quellen:
- https://stackoverflow.com/questions/65059267/how-do-i-implement-option-buttons-and-change-the-button-color-in-pygame
- https://stackoverflow.com/questions/49345616/highlighting-buttons-in-pygame
- https://stackoverflow.com/questions/47639826/pygame-button-single-click
- https://github.com/russs123/pygame_tutorials
- https://github.com/russs123/pygame_tutorials/blob/main/Button/button.py