DEBUG = False
#here you can choose the version
GRAPHIC_MODE = True
#if not automated you can play in text mode
AUTOMATED = True

COLOURS = ['lila', 'blue', 'green']
QUANTITIES = ['1', '2', '3']
FORMS = ['Spade', 'Heart', 'Club']
PLENTIES = ['full', 'empty', 'dashed']

#
TABLE_SIZE = 12

SCREEN_WIDTH, SCREEN_HEIGHT = (1100, 550)
FPS = 60
SET_SIZE = 3


INV_COLOR = (255, 255, 255, 255)

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

#dimensions and mise-en-page of the cards
CARD_WIDTH, CARD_HEIGHT = (250, 110)
NUM_COLUMNS, NUM_ROWS = (3, 3)
#gap between the cards and buttons
PADDING = 10
BUTTON_PADDING = 40
